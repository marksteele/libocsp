#ifndef ocsp_h__
#define ocsp_h__

extern int ocsp_check(char *cert, char *issuer, char *signer);

#endif
